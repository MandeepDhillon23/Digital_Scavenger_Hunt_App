<?php

require("dbconnection.php");

//Registration of new users
//			actionId: "registerAccount"
//			input: json encoded fields (email, name)
//			process: saving the fields to database
//			output: return 200

	// - users:

//{"userId":"U-478366645417",
// "displayName":"John Smith",
// "email":"john@smith.com"}

$response = array();

switch($_GET["action"]) {
	case "registerAccount":
        
		// 1. take the input
		$userDetails = $_POST;
        
        
		// 2. construct the query (for INSERT)		
        $statement = "INSERT INTO User(userId, displayName, emailAddress)
                         VALUES ('".$userDetails["userId"]."',
                                 '".$userDetails["displayName"]."',
							     '".$userDetails["email"]."')";
        
        
		// 3. return the response
		if($conn->query($statement)) {
			// all good
			$response["status"] = "200";
			$response["userId"] = $userDetails["userId"];
		}
		else {
			// not good
			$response["status"] = "500";
			$response["message"] = mysqli_error($conn);
			// $response["statement"] = $statement;
			// $response["data"] = serialize($_POST);
			
		}          
        
        
		break;
}

echo json_encode($response);
    
?>