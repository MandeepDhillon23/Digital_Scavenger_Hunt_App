<?php

require("dbconnection.php");

	// - challenges:
	

	

$response = array();

switch($_GET["action"]) {
	case "createChallenge":
		// 	- Creation of new challenges
		// 		actionId: "createChallenge"
		// 		input: json encoded data containing all waypoints, hints, challenge data, etc.
		// 		process: the server would store the challenges in the db & generate a new challengeId
		// 		output: return json encoded data {challengeId: xxxxxx}

		// {
		// 	"challengeId":"C-782659859550",
		// 	"name":"Find the Artwork!",
		// 	"authorId":"D-1477930626500",
		// 	"expiration":1556926706633,
		// 	"prizeInfo":{
		// 		"name":"name of the prize",
		// 		"type":"url",
		// 		"content":"https://www.iupui.edu/"
		// 	},
		// 	"waypoints":[
		// 		{
		// 			"waypointId":"W-1203884120741",
		// 			"type":"waypoint",
		// 			"location":{"lng":1234567,"lat":1234567,"alt":10},
		// 			"hint":"The hint message for this waypoint"
		// 		},{
		// 			"waypointId":"W-1096670351160",
		// 			"type":"waypoint",
		// 			"location":{"lng":7654321,"lat":7654321,"alt":5},
		// 			"hint":"The hint message for this second waypoint"
		// 		}
		// 	]
		// }

		// 1. take the input
		$challengeDetails = $_POST;


		// 2. construct the query (for INSERT)
		// $challengeId = uniqid("C-", true);

		$statement = "INSERT INTO Challenges 
						(challengeId, challengeDetails, authorId, expirationTimestamp) 
						VALUES ('".$challengeDetails["challengeId"]."', 
								\"".$conn->real_escape_string(serialize($challengeDetails))."\", 
								'".$challengeDetails["authorId"]."',
								".$challengeDetails["expiration"].")";

		// 3. return the response
		if($conn->query($statement)) {
			// all good
			$response["status"] = "200";
			$response["challengeId"] = $challengeDetails["challengeId"];
		}
		else {
			// not good
			$response["status"] = "500";
			$response["message"] = mysqli_error($conn);
			// $response["statement"] = $statement;
			// $response["data"] = serialize($_POST);
			
		}

		break;
	case "retireChallenge":
		// 	- Retirement of challenges by id from authors
		// 		actionId: "retireChallenge"
		// 		input: json encoded data {challengeId, userId}
		// 		process: verify user is the owner of the challenge, if so, delete the challenge from server.
		// 		output: return 200 for success

		$userInput = $_POST;

		// 1. construct the SELECT query to verify
		$statement = "SELECT * FROM Challenges WHERE authorId = '".$userInput["authorId"]."' AND challengeId='".$userInput["challengeId"]."';";

		$query = $conn->query($statement);

		$row = $query->fetch_assoc();

		if($row) {
			// verified

			// construct the statement
			$statement = "DELETE FROM Challenges WHERE challengeId='".$userInput["challengeId"]."';";
			$conn->query($statement);

			$response["status"] = "200";
			$response["message"] = "Challenge retired.";

		}
		else {
			// invalid request
			$response["status"] = "403";
			$response["message"] = "Permission denied.";
		}

		break;
	case "getChallengeInfo":

		// 	- Challenge validity check (see if challenge is still valid. it could expire, or has been completed by someone else)
		// 		actionId: "getChallengeInfo"
		// 		input: challengeId over GET
		// 		process: verify if challenge still exists. if so, load the data and return to user
		// 		output: return a json encoded data of the challenge details

		$challengeId = $_GET["challengeId"];

		// construct the statement
		$statement = "SELECT * FROM Challenges WHERE challengeId='$challengeId';";

		$query = $conn->query($statement);

		$row = $query->fetch_assoc();

		if(!$row) {
			// challenge not found
			$response["status"] = "404";
			$response["message"] = "Challenge not found";
		}
		else if($row["expirationTimestamp"] < time()) {
			// challenge expired
			$response["status"] = "406";
			$response["message"] = "Challenge already expired";
		}
		else {
			// must be valid.
			$response["status"] = "200";
			$response["challengeDetails"] = unserialize($row["challengeDetails"]);
		}

		break;
}

echo json_encode($response);

?>