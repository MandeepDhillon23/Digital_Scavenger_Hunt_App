<?php
//Connection 

$server = "localhost";
$username = "pkavoosi";
$password = "pkavoosi";
$database = "pkavoosi_db";
//create connection
$conn = new mysqli($server, $username, $password, $database);

// Check connection
if($conn-> connect_error) {
	die("Connection failed: " .$conn->connect_error);
	}
?>







