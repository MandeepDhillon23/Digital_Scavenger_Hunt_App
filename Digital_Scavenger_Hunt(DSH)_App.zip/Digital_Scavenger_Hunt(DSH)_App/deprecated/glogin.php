<?php

//echo "I can print";
//connect to database
require("dbconnection.php");

$username=$_POST['userName'];
$password=$_POST['password']; 


$sql = "SELECT username, password FROM User WHERE userName = '$username' and password = '$password'";


if (mysqli_query($conn, $sql)) {

session_start();
$_SESSION["signedIn"] = "1";

header('Location: profile.php'); 

} else{
echo "Invalid username or password.".mysqli_error($conn);
}

mysqli_close($conn);

 
?>

