<?php

require("dbconnection.php");


print_r($_POST);


// collect all field keys in an array
$sql_fieldKeys = array_keys($_POST);

// collect all field values in an array
$sql_fieldValues = array_values($_POST);

// escape all the values using "mysql_escape_string"
// array_walk($sql_fieldValues, "mysqli::real_escape_string");
array_walk($sql_fieldValues, "addQuote");

function addQuote(&$input) {
	
	$input = "\"".$GLOBALS["conn"]->real_escape_string($input)."\"";
}

// construct the actual SQL statement
$sql = "INSERT INTO User (".implode(",", $sql_fieldKeys).") VALUES (".implode(",", $sql_fieldValues).");";


echo "SQL statement is: " . $sql."<br />";

// exit();


if (mysqli_query($conn, $sql)) {
echo "New account created successfully, login now";
} else {
echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);

?>