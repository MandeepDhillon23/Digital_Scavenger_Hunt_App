Digital GeoCoaching

[UI & Interaction Design]
#Interaction Design - Creating challenges
- Users can register to save a name.
- Users can create a prize (the goal) and define its content. Text only for now.
- Users can move to a new location and create a clue using his current position. A waypoint with clue.
- Users can choose to add more waypoints.
- Prizes can be defined a count (1, X, or -1 for unlimited.) and an expiration date (default is 30 days from creation)

#Interaction Design - Solving challenges
- Users can choose to take a challenge, once started, the first clue becomes visible.
- If user makes it to the first waypoint, he unlocks the next waypoint, and the clue of the next waypoint becomes visible.
- A progress bar indicates how far away the user is from the target
- If the next unlocked waypoint is the goal, the user completes the challenge and the secret gets revealed.

#UI Design
- Navigation: Bottom toolbar with icons
- Home: A list with multiple cards:
	- Ongoing challenges
	- My own challenges
- Map view
	- shows pins of previously unlocked waypoints, tap on waypoints to see details (challenge name, hint, waypoint location, time unlocked, challenge progress)
	- shows pins of nearby waypoints
- Profile view
	- shows name, email, avatar (take from the wordpress database for now), date of account creation, and stats (# of ongoing challenges, # of completed challenges)
	
[Software Components]
#Client App (JS + OnsenUI + Cordova for iOS)
- Show a list of currently tracking challenges, and nearby challenges
- Allow users to select (activate) challenges
- Tap on a new challenge to see:
	- a brief description of the challenge
	- some stats:
		- number of users that are going through the challenge
		- the number of users who have completed the challenge
	- a button to accept / activate the challenge
- Tap on an *activated* challenge to see:
	- its current hint,
	- a map of where the user is,
	- a progress bar for overall completion progress,
	- and a button to verify if the user can unlock the waypoint.
- Tapping on the "Check my position" would:
	- send the current position (long, lat, alt) to server against this particular challengeId and indexId to see if user is within the right range
	- if so, return unlocked
	- if not, return no
- Once unlocked, the app would display a message to congratulate the user for the successful action, update the progress bar, and show the next hint.

#Server App (PHP + MySQL)
- API endpoints for:
	- users
		- Registration of new users
			actionId: "registerAccount"
			input: json encoded fields (email, name)
			process: saving the fields to database
			output: return 200

	- challenges:
		- Creation of new challenges
			actionId: "createChallenge"
			input: json encoded data containing all waypoints, hints, challenge data, etc.
			process: the server would store the challenges in the db & generate a new challengeId
			output: return json encoded data {challengeId: xxxxxx}

		- Retirement of challenges by id from authors
			actionId: "retireChallenge"
			input: json encoded data {challengeId, userId}
			process: verify user is the owner of the challenge, if so, delete the challenge from server.
			output: return 200 for success

		- Challenge validity check (see if challenge is still valid. it could expire, or has been completed by someone else)
			actionId: "getChallengeInfo"
			input: challengeId over GET
			process: verify if challenge still exists. if so, load the data and return to user
			output: return a json encoded data of the challenge details

	- waypoints:
		- obtain waypoint details
			actionId: "getWaypointDetails"
			input: json encoded data {challengeId, waypointIndex}
			process: look up challenge data, return details on the specific waypoint
			output: return a json encoded data of the waypoint details

		- get nearby waypoint info for challenge discovery
			actionId: "getNearbyWaypoints"
			input: json encoded lat/lng coordinate
			process: search through waypoints in database, identify nearby (+/- .015 degrees for 1 mile) waypoint data and locate its challenge details
			output: return a json encoded array of data containing challenge description 

		- waypoint verification
			actionId: "verifyWaypoint"
			input: json encoded data {challengeId, waypointIndex, lat, lng, alt}
			process: locate the waypoint via challengeId & waypointIndex, then see if user is in the region of the defined GPS marker.
			output: return json data {proximityLevel:int, waypointVerified:bool}
			
- Generate push notifications:
	- to authors that someone completed a challenge


[Data Structures]
#Waypoint Properties
- (string) challengeId
- (int) waypointIndex
- (float) longtitudeValue
- (float) latitutdeValue
- (float) altitudeValue
- (string) waypointHint
- (string) waypointReward

#Challenges Properties
- (string) challengeId
- (string) authorId
- (string) challengeDetails
- (int) expirationTimestamp

#User Properties
- (int) userId
- (string) displayName
- (int) creationTimestamp
- (string) emailAddress
- (bool) accountVerified
- (string) activeChallenges - JSON objects: [{challengeId: string, waypointIndex: int}]
- (string) completedChallenges - JSON objects: [{challengeId: string, completedTimestamp: int}]
- (string) deviceIds - JSON objects of user device unique identifiers for push notifications
