<?php

// require("dbconnection.php");

$response = array();

switch($_GET["action"]) {
	case "sayHello":
		
		$response = array(
			"status" => "200",
			"message" => "hello",
			"get" => $_GET,
			"post" => $_POST
		);
		break;
	default:
		$response = array(
			"status" => "000",
			"GET" => $_GET,
			"POST" => $_POST
		);
}

echo json_encode($response);

?>