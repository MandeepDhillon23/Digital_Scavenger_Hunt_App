<?php

// the connection part goes here.
$server = "localhost";
$username = "cmeng";
$password = "cmeng";
$database = "cmeng_db";
// Create connection
$conn = new mysqli($server, $username, $password, $database);
// Check connection
if($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}

// echo "Connected successfully";

?>