<?php

require("dbconnection.php");

$response = array();

switch($_GET["action"]) {
// 	case "getWaypointInfo":
// 	// - obtain waypoint details
// 	// 		actionId: "getWaypointDetails"
// 	// 		input: json encoded data {challengeId, waypointIndex}
// 	// 		process: look up challenge data, return details on the specific waypoint
// 	// 		output: return a json encoded data of the waypoint details

// 	$userInput = $_POST;

// 	// 2. construct the query (for INSERT)
// 		// $challengeId = uniqid("C-", true);

// 	// {"challengeId":"C-1258471712968","waypointIndex":0}

// 	$statement = "SELECT * FROM Waypoint WHERE challengeId = '".$userInput["challengeId"]."' AND waypointIndex='".$userInput["waypointIndex"]."';";

// 		$query = $conn->query($statement);

// 		$row = $query->fetch_assoc();

// 		if($row) {
// 			// verified

// 			// construct the statement
// 			$statement = "select * FROM Challenges WHERE challengeId='".$userInput["challengeId"]."';";
// 			$conn->query($statement);

// 			$response["status"] = "200";
// 			$response["waypointinfo"] = $row;

// 		}
// 		else {
// 			// invalid request
// 			$response["status"] = "603";
// 			$response["message"] = "No waypoint.";
// 		}

// 		break;
// // - get nearby waypoint info for challenge discovery
// // 			actionId: "getNearbyWaypoints"
// // 			input: json encoded lat/lng coordinate
// // 			process: search through waypoints in database, identify nearby waypoint data and locate its challenge details
// // 			output: return a json encoded array of data containing challenge description 		
// // }
	case "getNearbyWaypoints":

		$userInput = $_POST;

		// {"location":{"lng":123456,"lat":654321},"userId":"D-1443223360493"}
		// 1. construct the SELECT query to getNearbyWaypoints

		$statement = "SELECT Challenges.challengeId, Challenges.challengeDetails, Waypoint.latitudeValue, Waypoint.longitudeValue
					FROM Waypoint
					INNER join Challenges 
					ON Waypoint.challengeId=Challenges.challengeId 
					WHERE Challenges.expirationTimestamp >= ".(time() * 1000)."
					AND (longitudeValue BETWEEN ".($_POST['lng']-0.015)." AND ".($_POST['lng']+0.015).") 
					AND (latitudeValue BETWEEN ".($_POST['lat']-0.015)." AND ".($_POST['lat']+0.015).")
					AND Challenges.authorId != '".($conn->escape_string($_POST["userId"]))."';";
		
		$fp = fopen("sql.log", "a+");
		fputs($fp, $statement . "\n");
		fclose($fp);

		$query = $conn->query($statement);

		$response["status"] = "200";
		$response["waypoints"] = [];

		foreach($query as $row) {
			$response["waypoints"][] = [
				"challengeId" => $row["challengeId"],
				"lat" => $row["latitudeValue"] + (rand(-15, 15) / 1000),
				"lng" => $row["longitudeValue"] + (rand(-15, 15) / 1000)	//scramble the lat and lng
			];
		}

		

		break;

	case "verifyWaypointWithLocation":

		// 	- Challenge validity check (see if challenge is still valid. it could expire, or has been completed by someone else)
		// 		actionId: "getChallengeInfo"
		// 		input: challengeId over GET
		// 		process: verify if challenge still exists. if so, load the data and return to user
		// 		output: return a json encoded data of the challenge details


 		$userInput = $_POST;

		// construct the statement
		$statement = "SELECT * FROM Waypoint 
						WHERE challengeId='".$userInput["challengeId"]."' 
						AND waypointId = '".$userInput["waypointId"]."'
						AND (longitudeValue BETWEEN ".($userInput['location']['lng'] - 0.001)." AND ".($userInput['location']['lng'] + 0.001).")
						AND (latitudeValue BETWEEN ".($userInput['location']['lat'] - 0.001)." AND ".($userInput['location']['lat'] + 0.001).")
						AND (altitudeValue BETWEEN ".($userInput['location']['alt'] - 10)." AND ".($userInput['location']['alt'] + 10).");";
 
		$fp = fopen("sql.log", "a+");
		fputs($fp, $statement . "\n");
		fclose($fp);

		$query = $conn->query($statement);

		$row = $query->fetch_assoc();
// verify
		if(!$row) {
			// waypoint not found
			$response["status"] = "200";
			$response["waypointValidated"] = "0";
			$response["message"] = "waypoint invalid";
		
		}
		else {
			// must be valid.
			$response["status"] = "200";
			$response["waypointValidated"] = "1";
			$response["challengeId"] = $row["challengeId"];
			$response["waypointId"] = $row["waypointId"];
			$response["message"] = "Waypoint Valid";
		}

		break;
}


echo json_encode($response);




