<?php
header("Access-Control-Allow-Origin: *");

require("dbconnection.php");

//Registration of new users
//			actionId: "registerAccount"
//			input: json encoded fields (email, name)
//			process: saving the fields to database
//			output: return 200

	// - users:

//{"displayName":"John Smith",
// "email":"john@smith.com",
// "deviceId":"D-1537919228352"}

$response = array();

switch($_GET["action"]) {
	case "registerAccount":
        
		// 1. take the input
		$userDetails = $_POST;
        
        
		// 2. construct the query (for INSERT)		
        $statement = "INSERT INTO User(displayName, emailAddress, userId, creationTimestamp)
                    VALUES ('".$userDetails["displayName"]."',
                            '".$userDetails["emailAddress"]."',
							'".$userDetails["userId"]."',
							".(time() * 1000).")";
        
        
		// 3. return the response
		if($conn->query($statement)) {
			// all good
			$response["status"] = "200";
			$response["userId"] = $userDetails["userId"];
		}
		else {
			// not good
			$response["status"] = "500";
			$response["message"] = mysqli_error($conn);
			// $response["statement"] = $statement;
			// $response["data"] = serialize($_POST);
			
		}          
        
        
		break;
}

echo json_encode($response);

    
        
?>