<?php
header("Access-Control-Allow-Origin: *");

require("dbconnection.php");

	// - challenges:
	

	

$response = array();

switch($_GET["action"]) {
	case "createChallenge":
		// 1. take the input
		$challengeDetails = $_POST;


		// 2. construct the query (for INSERT)
		// $challengeId = uniqid("C-", true);

		$statement = "INSERT INTO Challenges 
						(challengeId, challengeDetails, authorId, expirationTimestamp) 
						VALUES ('".$challengeDetails["challengeId"]."', 
								\"".$conn->real_escape_string(serialize($challengeDetails))."\", 
								'".$challengeDetails["authorId"]."',
								".$challengeDetails["expiration"].")";

		// 2.1 extract waypoint info and save to table


		for($waypointIndex = 0; $waypointIndex < count($challengeDetails["waypoints"]); $waypointIndex ++) {
			$waypointInfo = $challengeDetails["waypoints"][$waypointIndex];

			$waypointStatement = "INSERT INTO Waypoint (challengeId, waypointId, longitudeValue, latitudeValue, altitudeValue, waypointHint)
			 						VALUES ('".$challengeDetails["challengeId"]."',
			 								'".$waypointInfo["waypointId"]."',
			 								'".$waypointInfo["location"]["lng"]."',
			 								'".$waypointInfo["location"]["lat"]."',
			 								'".$waypointInfo["location"]["alt"]."',
			 								\"".$waypointInfo["hint"]."\");";

			$fp = fopen("sql.log", "a+");
			fputs($fp, $waypointStatement . "\n");
			fclose($fp);

			$conn->query($waypointStatement);

		}

		// 3. return the response
		if($conn->query($statement)) {
			// all good
			$response["status"] = "200";
			$response["challengeId"] = $challengeDetails["challengeId"];
		}
		else {
			// not good
			$response["status"] = "500";
			$response["message"] = mysqli_error($conn);
			$response["statement"] = $statement;
			// $response["data"] = serialize($_POST);
			
		}

		break;
	case "retireChallenge":
		// 	- Retirement of challenges by id from authors
		// 		actionId: "retireChallenge"
		// 		input: json encoded data {challengeId, userId}
		// 		process: verify user is the owner of the challenge, if so, delete the challenge from server.
		// 		output: return 200 for success

		$userInput = $_POST;

		// 1. construct the SELECT query to verify
		$statement = "SELECT * FROM Challenges WHERE authorId = '".$userInput["authorId"]."' AND challengeId='".$userInput["challengeId"]."';";

		$query = $conn->query($statement);

		$row = $query->fetch_assoc();

		if($row) {
			// verified

			// construct the statement
			$statement = "DELETE FROM Challenges WHERE challengeId='".$userInput["challengeId"]."';";
			$conn->query($statement);

			$response["status"] = "200";
			$response["message"] = "Challenge retired.";

		}
		else {
			// invalid request
			$response["status"] = "403";
			$response["message"] = "Permission denied.";
		}

		break;
	case "getChallengeInfo":

		// 	- Challenge validity check (see if challenge is still valid. it could expire, or has been completed by someone else)
		// 		actionId: "getChallengeInfo"
		// 		input: challengeId over GET
		// 		process: verify if challenge still exists. if so, load the data and return to user
		// 		output: return a json encoded data of the challenge details

		$challengeId = $_POST["challengeId"];

		// construct the statement
		$statement = "SELECT Challenges.challengeId, Challenges.authorId, Challenges.expirationTimestamp, Challenges.challengeDetails, User.displayName
						FROM Challenges 
						INNER JOIN User
						ON Challenges.authorId = User.userId 
						WHERE challengeId='$challengeId';";

		$query = $conn->query($statement);

		$row = $query->fetch_assoc();



		if(!$row) {
			// challenge not found
			$response["status"] = "404";
			$response["challengeId"] = $challengeId;
			$response["message"] = "Challenge not found";
		}
		else if($row["expirationTimestamp"] < time()) {
			// challenge expired
			$response["status"] = "406";
			$response["message"] = "Challenge already expired";
		}
		else {
			// must be valid.

			$fp = fopen("logs.txt", "r");
			fputs($fp, print_r($row, true));
			fclose($fp);

			$challengeDetails = unserialize($row["challengeDetails"]);
			$challengeDetails["authorName"] = $row["displayName"];
			$response["status"] = "200";
			$response["challengeDetails"] = $challengeDetails;
		}

		break;
}

echo json_encode($response);

?>